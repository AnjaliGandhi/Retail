package com.demo.dao;




import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.demo.associate.Associate;
import com.demo.dbutil.DBUtil;

public class AssociateDAO {

	private String associate_Skills;
	public  int addAssociate(Associate a) {
		// TODO Auto-generated method stub
		
		int x=0;
		Connection con=null;
		PreparedStatement prst=null;
	
		try{
			System.out.println("action");
			con=DBUtil.getConnection();
			
			prst=con.prepareStatement("insert into Associate values (?,?,?,?,?,?)");
			prst.setInt(1,a.getAssociate_Id());
			prst.setString(2, a.getAssociate_Name());
			prst.setString(3, a.getAssociate_Gender());
			prst.setString(4, a.getAssociate_Ilp());
			prst.setString(5, a.getAssociate_Branch());
			prst.setString(6, a.getAssociate_Skills());
			x=prst.executeUpdate();
			
		}
		
		catch (Exception e) {
				System.out.println(e);
		}
		finally{
			DBUtil.closeConnection(con);
			DBUtil.closeStatement(prst);
		}
	
		return x;
		
	}
	public  ArrayList<Associate> SearchAssociate(int associate_Id) {
		// TODO Auto-generated method stub
		ArrayList<Associate> searchitems=new ArrayList<Associate>();
		Connection con=null;
		PreparedStatement prst=null;
		ResultSet rs=null;
		
		try{
			con=DBUtil.getConnection();
			prst=con.prepareStatement("select * from Associate where Associate_Id=?");
			prst.setInt(1,associate_Id);
			
			rs=prst.executeQuery();
			while(rs.next()){
				Associate a=new Associate();
				a.setAssociate_Id(rs.getInt(1));
				a.setAssociate_Name(rs.getString(2));
				a.setAssociate_Gender(rs.getString(3));
				a.setAssociate_Ilp(rs.getString(4));
				a.setAssociate_Branch(rs.getString(5));
				a.setAssociate_Skills(rs.getString(6));
			
				searchitems.add(a);
			}
		
		}
		catch (Exception e) {
				System.out.println(e);
		}
		finally{
			DBUtil.closeConnection(con);
			DBUtil.closeStatement(prst);
		}
		
		return searchitems;
		
	}
	
	
	public  ArrayList<Associate> updateAssociate(int associate_Id,Associate as) {
		// TODO Auto-generated method stub
		
		Connection con=null;
		PreparedStatement prst=null;
		PreparedStatement prst1=null;
		ResultSet rs=null;
		ArrayList<Associate> c1=new ArrayList<Associate>();
		String updsql="update Associate set Associate_Skills=? where Associate_Id=?";
		String query="select * from Associate where Associate_Id=?";
		
		try{
			con=DBUtil.getConnection();
			prst=con.prepareStatement(updsql);
			prst.setString(1,as.getAssociate_Skills());
			prst.setInt(2,associate_Id);
			prst.executeUpdate();
			
			prst1=con.prepareStatement(query);	
			prst1.setInt(1,associate_Id);
			rs=prst1.executeQuery();
			
			
			while(rs.next()){
			
				as.setAssociate_Id(rs.getInt(1));
				as.setAssociate_Name(rs.getString(2));
				as.setAssociate_Gender(rs.getString(3));
				as.setAssociate_Ilp(rs.getString(4));
				as.setAssociate_Branch(rs.getString(5));
				as.setAssociate_Skills(rs.getString(6));
			
				c1.add(as);
			}
		
			
		
		}
		catch (Exception e) {
				System.out.println(e);
		}
		finally{
			DBUtil.closeConnection(con);
			DBUtil.closeStatement(prst);
		}
		
	
		return c1;
	}
	

	public  ArrayList<Associate> viewAllAssociates() {
		// TODO Auto-generated method stub
		ArrayList<Associate> searchitems=new ArrayList<Associate>();
		Connection con=null;
		PreparedStatement prst=null;
		ResultSet rs=null;
		
		try{
			con=DBUtil.getConnection();
			prst=con.prepareStatement("select * from Associate");
			rs=prst.executeQuery();
			while(rs.next()){
				Associate a=new Associate();
				a.setAssociate_Id(rs.getInt(1));
				a.setAssociate_Name(rs.getString(2));
				a.setAssociate_Gender(rs.getString(3));
				a.setAssociate_Ilp(rs.getString(4));
				a.setAssociate_Branch(rs.getString(5));
				a.setAssociate_Skills(rs.getString(6));
			
				searchitems.add(a);
			}
		
		}
		catch (Exception e) {
				System.out.println(e);
		}
		finally{
			DBUtil.closeConnection(con);
			DBUtil.closeStatement(prst);
		}
		
		return searchitems;
		
	}
	public  int deleteAssociate(int associate_Id) {
		// TODO Auto-generated method stub
		int isDeleted=0;
		Connection con=null;
		PreparedStatement prst=null;
		
		try{
			con=DBUtil.getConnection();
			prst=con.prepareStatement("delete from Associate where Associate_Id=?");
		
			prst.setInt(1, associate_Id);
			int x=prst.executeUpdate();
			if(x>0)
				isDeleted=1;
		}
		catch (Exception e) {
				System.out.println(e);
		}
		finally{
			DBUtil.closeConnection(con);
			DBUtil.closeStatement(prst);
		}
		
		return isDeleted;
		
	}
	

}

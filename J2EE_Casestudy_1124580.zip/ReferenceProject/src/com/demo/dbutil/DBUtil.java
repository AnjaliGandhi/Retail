package com.demo.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBUtil {
	public static Connection getConnection(){
		Connection con=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@inchnilpdb03.India.TCS.com:1521:JAVADB03", "E1124580", "E1124580");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
	public static void closeConnection(Connection con)
	{
	  if(con!=null)
		  {
		    try
		      {
			  con.close();  
		      }
		  catch(Exception e)
		      {
			  e.printStackTrace();
		      }
		  }
	}
public static void closeStatement(PreparedStatement ps)
{
	if(ps!=null)
	{
		try
		{
			ps.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}


public static void closeResultSet(ResultSet rs)
{
	if(rs!=null)
	{
		try
		{
			rs.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}

}



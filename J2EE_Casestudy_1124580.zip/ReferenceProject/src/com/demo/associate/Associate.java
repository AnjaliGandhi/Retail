package com.demo.associate;

public class Associate {
	private int Associate_Id;
	private String Associate_Name;
	private String Associate_Gender;
	private String Associate_Ilp_Location ;
	private String Associate_Branch;
	private String Associate_Skills;
/*	public Associate(int associate_Id, String associate_Name,
			String associate_Gender, String associate_Ilp_Location,
			String associate_Branch, String associate_Skills) {
		super();
		Associate_Id = associate_Id;
		Associate_Name = associate_Name;
		Associate_Gender = associate_Gender;
		Associate_Ilp_Location = associate_Ilp_Location;
		Associate_Branch = associate_Branch;
		Associate_Skills = associate_Skills;
	}*/
	public int getAssociate_Id() {
		return Associate_Id;
	}
	public void setAssociate_Id(int associate_Id) {
		Associate_Id = associate_Id;
	}
	public String getAssociate_Name() {
		return Associate_Name;
	}
	public void setAssociate_Name(String associate_Name) {
		Associate_Name = associate_Name;
	}
	public String getAssociate_Gender() {
		return Associate_Gender;
	}
	public void setAssociate_Gender(String associate_Gender) {
		Associate_Gender = associate_Gender;
	}
	public String getAssociate_Ilp() {
		return Associate_Ilp_Location;
	}
	public void setAssociate_Ilp(String associate_Ilp_Location) {
		Associate_Ilp_Location = associate_Ilp_Location;
	}
	public String getAssociate_Branch() {
		return Associate_Branch;
	}
	public void setAssociate_Branch(String associate_Branch) {
		Associate_Branch = associate_Branch;
	}
	public String getAssociate_Skills() {
		return Associate_Skills;
	}
	public void setAssociate_Skills(String associate_Skills) {
		Associate_Skills = associate_Skills;
	}
	
}

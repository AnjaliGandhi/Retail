import java.lang.Package;
public abstract class Shape 
{
	abstract void findTriangle(double b, double h);
	abstract void findRectangle(double l, double b);
	abstract void findSquare(double s);
	abstract void findCircle(double r);
	
}

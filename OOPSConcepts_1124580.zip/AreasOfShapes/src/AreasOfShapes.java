import java.lang.Package;
public class AreasOfShapes 
{
	private double l;
	private double b;
	private double h;
	private double r;
	private double s;
	
	public AreasOfShapes() {
		// TODO Auto-generated constructor stub
		this.l=l;
		this.b=b;
		this.h=h;
		this.r=r;
		this.s=s;
		
	}

	public double getL() {
		return l;
	}

	public void setL(double l) {
		this.l = l;
	}

	public double getB() {
		return b;
	}

	public void setB(double b) {
		this.b = b;
	}

	public double getH() {
		return h;
	}

	public void setH(double h) {
		this.h = h;
	}

	public double getR() {
		return r;
	}

	public void setR(double r) {
		this.r = r;
	}

	public double getS() {
		return s;
	}

	public void setS(double s) {
		this.s = s;
	}
	
}


	